import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';

import { CustomerService } from '../customer.service';
import { AngularFireMessaging } from "@angular/fire/messaging";

@Component({
  selector: 'customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.scss']
})
export class CustomersListComponent implements OnInit {

  customers: any;

  constructor(private customerService: CustomerService,
    private angularFireMessaging: AngularFireMessaging) { 
      this.angularFireMessaging.messaging.subscribe(_messaging => {
        _messaging.onMessage = _messaging.onMessage.bind(_messaging);
        _messaging.onTokenRefresh = _messaging.onTokenRefresh.bind(_messaging);
      });
    }

  ngOnInit() {
    this.requestPermission();
    this.getCustomersList();
  }
  requestPermission() {
    this.angularFireMessaging.requestToken.subscribe(
      token => {
        console.log(token)
        if (token) {
          //this.updateToken(token);
        }
      },
      err => {
        console.error("Unable to get permission to notify.", err);
      }
    );
  }
  getCustomersList() {
    // Use snapshotChanges().map() to store the key
    this.customerService.getCustomersList().snapshotChanges().pipe(
      map(changes =>
        changes.map(c => ({ key: c.payload.key, ...c.payload.val() }))
      )
    ).subscribe(customers => {
      console.log(customers);
      this.customers = customers;
      
    });
  }

  deleteCustomers() {
    this.customerService.deleteAll();
  }

}
